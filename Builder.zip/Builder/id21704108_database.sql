-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2024 at 07:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id21704108_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `business_card`
--

CREATE TABLE `business_card` (
  `id` int(11) NOT NULL,
  `company_logo` varchar(255) DEFAULT NULL,
  `personal_image` varchar(255) DEFAULT NULL,
  `company_name` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `profession` varchar(50) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `business_card`
--

INSERT INTO `business_card` (`id`, `company_logo`, `personal_image`, `company_name`, `user_name`, `phone_number`, `profession`, `facebook`, `twitter`, `email`) VALUES
(1, '/images/logo1.jpg', '/images/user1.jpg', 'ABC Corporation', 'John Doe', '1234567890', 'Software Developer', 'https://facebook.com/johndoe', 'https://twitter.com/johndoe', 'johndoe@example.com'),
(2, '/images/logo2.jpg', '/images/user2.jpg', 'XYZ Ltd', 'Jane Smith', '9876543210', 'Product Manager', 'https://facebook.com/janesmith', 'https://twitter.com/janesmith', 'janesmith@example.com'),
(3, '/images/logo3.jpg', '/images/user3.jpg', 'Tech Innovations', 'Michael Johnson', '4567891230', 'Data Scientist', 'https://facebook.com/michaeljohnson', 'https://twitter.com/michaeljohnson', 'michaelj@example.com'),
(4, '/images/logo4.jpg', '/images/user4.jpg', 'Global Solutions', 'Emily Davis', '2345678901', 'UX Designer', 'https://facebook.com/emilydavis', 'https://twitter.com/emilydavis', 'emilyd@example.com'),
(5, '/images/logo5.jpg', '/images/user5.jpg', 'FinTech Co.', 'David Brown', '3456789012', 'Business Analyst', 'https://facebook.com/davidbrown', 'https://twitter.com/davidbrown', 'davidb@example.com'),
(6, '/images/logo6.jpg', '/images/user6.jpg', 'Creative Works', 'Sophia Lee', '5678901234', 'Marketing Specialist', 'https://facebook.com/sophialee', 'https://twitter.com/sophialee', 'sophial@example.com'),
(7, '/images/logo7.jpg', '/images/user7.jpg', 'Innovative Tech', 'Daniel Kim', '6789012345', 'Software Engineer', 'https://facebook.com/danielkim', 'https://twitter.com/danielkim', 'danielk@example.com'),
(8, '/images/logo8.jpg', '/images/user8.jpg', 'Design Hub', 'Olivia Miller', '7890123456', 'Graphic Designer', 'https://facebook.com/oliviamiller', 'https://twitter.com/oliviamiller', 'oliviam@example.com'),
(9, '/images/logo9.jpg', '/images/user9.jpg', 'CloudNet', 'Ethan Harris', '8901234567', 'Cloud Architect', 'https://facebook.com/ethanharris', 'https://twitter.com/ethanharris', 'ethanh@example.com'),
(10, '/images/logo10.jpg', '/images/user10.jpg', 'Tech Solutions', 'Isabella Martinez', '9012345678', 'Project Manager', 'https://facebook.com/isabellamartinez', 'https://twitter.com/isabellamartinez', 'isabellam@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `connect`
--

CREATE TABLE `connect` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `connect`
--

INSERT INTO `connect` (`id`, `email`, `password`) VALUES
(1, 'alice.johnson@example.com', 'password123'),
(2, 'bob.smith@example.com', 'password123'),
(3, 'charlie.brown@example.com', 'password123'),
(4, 'dana.green@example.com', 'password123'),
(5, 'eve.white@example.com', 'password123'),
(6, 'frank.black@example.com', 'password123'),
(7, 'grace.grey@example.com', 'password123'),
(8, 'harry.red@example.com', 'password123'),
(9, 'ivy.blue@example.com', 'password123'),
(10, 'jack.silver@example.com', 'password123'),
(11, 'kathy.brown@example.com', 'password123'),
(12, 'liam.green@example.com', 'password123'),
(13, 'mona.white@example.com', 'password123'),
(14, 'noah.blue@example.com', 'password123'),
(15, 'olivia.black@example.com', 'password123'),
(16, 'paul.brown@example.com', 'password123'),
(17, 'quincy.blue@example.com', 'password123'),
(18, 'rachel.green@example.com', 'password123'),
(19, 'sam.white@example.com', 'password123'),
(20, 'tina.grey@example.com', 'password123');

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE `resume` (
  `id` int(11) NOT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `objective` text DEFAULT NULL,
  `qualification` text DEFAULT NULL,
  `work_experience` text DEFAULT NULL,
  `skills` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`id`, `profile_photo`, `name`, `email`, `phone_number`, `address`, `facebook`, `instagram`, `linkedin`, `objective`, `qualification`, `work_experience`, `skills`) VALUES
(1, '/images/photo1.jpg', 'Alice Johnson', 'alice.johnson@example.com', '1234567890', '1234 Elm St, City, Country', 'https://facebook.com/alicejohnson', 'https://instagram.com/alicejohnson', 'https://linkedin.com/in/alicejohnson', 'A passionate software engineer with a focus on scalable systems.', 'BSc in Computer Science from University X', 'Junior Software Developer at XYZ Ltd (2021-2023)', 'Java, Python, SQL'),
(2, '/images/photo2.jpg', 'Bob Smith', 'bob.smith@example.com', '2345678901', '5678 Oak St, City, Country', 'https://facebook.com/bobsmith', 'https://instagram.com/bobsmith', 'https://linkedin.com/in/bobsmith', 'Data-driven analyst with a knack for uncovering insights.', 'MSc in Data Science from University Y', 'Data Analyst Intern at ABC Corp (2020-2021)', 'SQL, Excel, Python'),
(3, '/images/photo3.jpg', 'Charlie Brown', 'charlie.brown@example.com', '3456789012', '9101 Pine St, City, Country', 'https://facebook.com/charliebrown', 'https://instagram.com/charliebrown', 'https://linkedin.com/in/charliebrown', 'Experienced UI/UX designer with a strong eye for detail.', 'BDes in Graphic Design from University Z', 'UI Designer at DEF Ltd (2019-2022)', 'Sketch, Figma, Adobe XD'),
(4, '/images/photo4.jpg', 'Dana Green', 'dana.green@example.com', '4567890123', '1122 Maple St, City, Country', 'https://facebook.com/danagreen', 'https://instagram.com/danagreen', 'https://linkedin.com/in/danagreen', 'Full-stack developer with expertise in front-end and back-end technologies.', 'B.Tech in Computer Science from University A', 'Front-end Developer at GHI Tech (2020-2023)', 'HTML, CSS, JavaScript, React'),
(5, '/images/photo5.jpg', 'Eve White', 'eve.white@example.com', '5678901234', '2233 Birch St, City, Country', 'https://facebook.com/evewhite', 'https://instagram.com/evewhite', 'https://linkedin.com/in/evewhite', 'A skilled project manager with over 5 years of experience in the tech industry.', 'MBA from University B', 'Project Manager at JKL Enterprises (2018-2023)', 'Project Management, Agile, Leadership'),
(6, '/images/photo6.jpg', 'Frank Black', 'frank.black@example.com', '6789012345', '3344 Cedar St, City, Country', 'https://facebook.com/frankblack', 'https://instagram.com/frankblack', 'https://linkedin.com/in/frankblack', 'Creative designer with a strong portfolio of branding and digital design.', 'BA in Visual Arts from University C', 'Freelance Graphic Designer (2019-Present)', 'Adobe Photoshop, Illustrator, InDesign'),
(7, '/images/photo7.jpg', 'Grace Grey', 'grace.grey@example.com', '7890123456', '4455 Willow St, City, Country', 'https://facebook.com/gracegrey', 'https://instagram.com/gracegrey', 'https://linkedin.com/in/gracegrey', 'Network engineer with a strong foundation in infrastructure and cloud technologies.', 'BSc in Information Technology from University D', 'Network Engineer at MNO Tech (2021-2023)', 'Cisco, Cloud Computing, Network Security'),
(8, '/images/photo8.jpg', 'Harry Red', 'harry.red@example.com', '8901234567', '5566 Fir St, City, Country', 'https://facebook.com/harryred', 'https://instagram.com/harryred', 'https://linkedin.com/in/harryred', 'SEO expert with proven results in improving website traffic and search engine rankings.', 'BA in Marketing from University E', 'SEO Specialist at PQR Solutions (2020-2022)', 'SEO, Google Analytics, SEM'),
(9, '/images/photo9.jpg', 'Ivy Blue', 'ivy.blue@example.com', '9012345678', '6677 Redwood St, City, Country', 'https://facebook.com/ivyblue', 'https://instagram.com/ivyblue', 'https://linkedin.com/in/ivyblue', 'Data scientist with expertise in machine learning and big data analytics.', 'MSc in Data Science from University F', 'Data Scientist at STU Analytics (2021-Present)', 'Python, R, Machine Learning'),
(10, '/images/photo10.jpg', 'Jack Silver', 'jack.silver@example.com', '0123456789', '7788 Birchwood St, City, Country', 'https://facebook.com/jacksilver', 'https://instagram.com/jacksilver', 'https://linkedin.com/in/jacksilver', 'Creative web designer with a focus on clean and responsive designs.', 'BFA in Digital Media from University G', 'Web Designer at VWX Studio (2020-2022)', 'HTML, CSS, WordPress'),
(11, '/images/photo11.jpg', 'Kathy Brown', 'kathy.brown@example.com', '1234567891', '8899 Ash St, City, Country', 'https://facebook.com/kathybrown', 'https://instagram.com/kathybrown', 'https://linkedin.com/in/kathybrown', 'Content writer with a passion for storytelling and creating engaging content.', 'BA in English from University H', 'Content Writer at YZA Media (2019-Present)', 'Writing, Editing, Content Strategy'),
(12, '/images/photo12.jpg', 'Liam Green', 'liam.green@example.com', '2345678902', '9900 Maple St, City, Country', 'https://facebook.com/liamgreen', 'https://instagram.com/liamgreen', 'https://linkedin.com/in/liamgreen', 'Experienced cloud architect with expertise in designing scalable cloud solutions.', 'MSc in Cloud Computing from University I', 'Cloud Architect at BCD Tech (2020-Present)', 'AWS, Azure, Cloud Infrastructure'),
(13, '/images/photo13.jpg', 'Mona White', 'mona.white@example.com', '3456789013', '1011 Pine St, City, Country', 'https://facebook.com/monawhite', 'https://instagram.com/monawhite', 'https://linkedin.com/in/monawhite', 'Detail-oriented software tester with a passion for quality assurance.', 'BSc in Information Technology from University J', 'Software Tester at EFG Tech (2020-2022)', 'Testing, Automation, Selenium'),
(14, '/images/photo14.jpg', 'Noah Blue', 'noah.blue@example.com', '4567890124', '1122 Maple Ave, City, Country', 'https://facebook.com/noahblue', 'https://instagram.com/noahblue', 'https://linkedin.com/in/noahblue', 'DevOps engineer with experience in automating deployment pipelines and CI/CD processes.', 'B.Tech in Computer Science from University K', 'DevOps Engineer at HIJ Solutions (2021-Present)', 'Docker, Kubernetes, CI/CD'),
(15, '/images/photo15.jpg', 'Olivia Black', 'olivia.black@example.com', '5678901235', '2233 Oak Ave, City, Country', 'https://facebook.com/oliviablack', 'https://instagram.com/oliviablack', 'https://linkedin.com/in/oliviablack', 'Video editor with a strong background in producing engaging and creative content.', 'BA in Film Production from University L', 'Video Editor at KLM Productions (2019-2022)', 'Adobe Premiere, Final Cut Pro, After Effects'),
(16, '/images/photo16.jpg', 'Paul Brown', 'paul.brown@example.com', '6789012346', '3344 Cedar Ave, City, Country', 'https://facebook.com/paulbrown', 'https://instagram.com/paulbrown', 'https://linkedin.com/in/paulbrown', 'Product designer with a focus on user-centered design principles.', 'BSc in Industrial Design from University M', 'Product Designer at NOP Tech (2021-Present)', 'SolidWorks, SketchUp, Prototyping'),
(17, '/images/photo17.jpg', 'Quincy Blue', 'quincy.blue@example.com', '7890123457', '4455 Pine Ave, City, Country', 'https://facebook.com/quincyblue', 'https://instagram.com/quincyblue', 'https://linkedin.com/in/quincyblue', 'Network administrator with expertise in managing and maintaining network infrastructure.', 'BSc in Networking from University N', 'Network Administrator at PQR Tech (2020-2023)', 'Networking, Security, VPN'),
(18, '/images/photo18.jpg', 'Rachel Green', 'rachel.green@example.com', '8901234568', '5566 Birch Ave, City, Country', 'https://facebook.com/rachelgreen', 'https://instagram.com/rachelgreen', 'https://linkedin.com/in/rachelgreen', 'Business analyst with experience in driving data-driven decisions and process improvements.', 'MBA from University O', 'Business Analyst at STU Analytics (2021-Present)', 'Business Analysis, SQL, Power BI'),
(19, '/images/photo19.jpg', 'Sam White', 'sam.white@example.com', '9012345679', '6677 Cedar Ave, City, Country', 'https://facebook.com/samwhite', 'https://instagram.com/samwhite', 'https://linkedin.com/in/samwhite', 'HR manager with expertise in recruitment, employee relations, and organizational development.', 'BSc in Human Resources from University P', 'HR Manager at XYZ Corp (2019-2022)', 'Recruitment, HRM, Employee Relations'),
(20, '/images/photo20.jpg', 'Tina Grey', 'tina.grey@example.com', '0123456780', '7788 Redwood Ave, City, Country', 'https://facebook.com/tinagrey', 'https://instagram.com/tinagrey', 'https://linkedin.com/in/tinagrey', 'Creative strategist with a strong ability to lead innovative marketing campaigns.', 'BSc in Marketing from University Q', 'Marketing Strategist at ABC Marketing (2021-Present)', 'SEO, Content Marketing, Strategy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `business_card`
--
ALTER TABLE `business_card`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `connect`
--
ALTER TABLE `connect`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `business_card`
--
ALTER TABLE `business_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `connect`
--
ALTER TABLE `connect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `resume`
--
ALTER TABLE `resume`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
