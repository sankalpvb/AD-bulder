let currentCard = 1;

function nextCard() {
  const currentCardElement = document.getElementById(`card${currentCard}`);
  currentCardElement.style.display = 'none';

  currentCard = (currentCard % 10) + 1; // Wrap around to the first card after the last card

  const nextCardElement = document.getElementById(`card${currentCard}`);
  nextCardElement.style.display = 'block';
}

function previousCard() {
  const currentCardElement = document.getElementById(`card${currentCard}`);
  currentCardElement.style.display = 'none';

  currentCard = (currentCard - 2 + 10) % 10 + 1; // Wrap around to the last card before the first card

  const previousCardElement = document.getElementById(`card${currentCard}`);
  previousCardElement.style.display = 'block';
}
