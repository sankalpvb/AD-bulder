function addNewWEfield() {
    let newNode=document.createElement('textarea');
    newNode.classList.add('form-control');
    newNode.classList.add('wefield');
    newNode.setAttribute('placeholder','Enter Here')

    let weOb=document.getElementById('we');

    let weadddbuttonOb=document.getElementById('weadddbutton');

    weOb.insertBefore(newNode,weadddbuttonOb);
}

//genrating cv function code

function generateCV(){
    //console.log("generating CV");
     

    let namefield=document.getElementById('namefield').value;

    let namet1=document.getElementById('namet1');

    namet1.innerHTML = namefield;

    document.getElementById('namet2').innerHTML=namefield;

    //email

    
    document.getElementById('emailt').innerHTML=document.getElementById('emailfield').value;



    //phone

    
    document.getElementById('phonet').innerHTML=document.getElementById('phonefield').value;

    //Address

    
    document.getElementById('addresst').innerHTML=document.getElementById('addressfield').value;

    //email
    
    document.getElementById('fbt').innerHTML=document.getElementById('fbfield').value;

    document.getElementById('instat').innerHTML=document.getElementById('igfield').value;

    document.getElementById('linkt').innerHTML=document.getElementById('linkfield').value;

    //objeective

    document.getElementById('objectt').innerHTML=document.getElementById('objectfield').value;
    //

    //qualification

    document.getElementById('quat').innerHTML=document.getElementById('qefield').value;  

    //work exp


    let wes=document.getElementsByClassName('form-control wefield');
    let str="";

    for (let e of wes) {
        str = str + `<li>${e.value}</li>`;
    }

    document.getElementById('wet').innerHTML = str;

    //skill

    document.getElementById('skillt').innerHTML=document.getElementById('skillfield').value;
    


    //photo

    let fileInput = document.getElementById('imgfield');
let file = fileInput.files[0];

console.log(file);

let reader = new FileReader();

// Set up an event listener for the 'load' event
reader.onload = function() {
    console.log(reader.result);
};

// Read the file as a data URL
reader.readAsDataURL(file);


    //img to temp

    reader.onload = function(){
        document.getElementById("imgt").src=reader.result;
    }




    //page change
    document.getElementById('cvform').style.display='none'
    document.getElementById('cvtemp').style.display='block';

   // Display alert message
   setTimeout(function() {
    // Display alert message after 5 seconds
    alert("Your CV is ready for download!");
    
    // Initiate print dialog after showing the alert
    window.print();
}, 5000);

    




    
}

 //printing
 