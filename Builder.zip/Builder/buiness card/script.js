// script.js

function generate() {
    // Fetching user input data
    const companyName = document.getElementById('cname').value;
    const yourName = document.getElementById('name').value;
    const phoneNumber = document.getElementById('phonefield').value;
    const profession = document.getElementById('pro').value;
    const facebookLink = document.getElementById('facebook').value;
    const twitterLink = document.getElementById('twitter').value;
    const emailLink = document.getElementById('eamil').value;

    // Fetching image file inputs
    const companyLogoFile = document.getElementById('image').files[0];
    const yourImageFile = document.getElementById('image1').files[0];

    // Check if any of the required fields are empty
    if (
        companyName === '' ||
        yourName === '' ||
        phoneNumber === '' ||
        profession === '' ||
        facebookLink === '' ||
        twitterLink === '' ||
        emailLink === ''
    ) {
        alert('Please fill in all required fields.');
        return;
    }

    // Check if both image files are selected
    if (!companyLogoFile || !yourImageFile) {
        alert('Please select both company/logo and your images.');
        return;
    }

    // Updating business card with user input
    document.getElementById('companyName').innerText = companyName;
    document.getElementById('yourName').innerText = yourName;
    document.getElementById('phoneNumber').innerText = phoneNumber;
    document.getElementById('profession').innerText = profession;
    document.getElementById('facebookLink').innerText = facebookLink;
    document.getElementById('twitterLink').innerText = twitterLink;
    document.getElementById('emailLink').innerText = emailLink;

    // Displaying image in the front side
    const frontImage = document.getElementById('img');
    frontImage.src = URL.createObjectURL(companyLogoFile);
    frontImage.alt = 'Company Logo';

    // Displaying image in the back side
    const backImage = document.getElementById('img1');
    backImage.src = URL.createObjectURL(yourImageFile);
    backImage.alt = 'Your Image';

    document.getElementById('formPage').style.display = 'none';
    document.getElementById('displayPage').style.display = 'block';
}

